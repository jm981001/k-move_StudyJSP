select *
from EMPLOYEE;
select * from members;
create table members(
     id varchar(50) constraint members_id_pk primary key,
     passwd varchar(20) constraint members_passwd_nn not null,
     name varchar(30) constraint members_name_nn not null,
     reg_date date constraint members_regdate_nn not null
);

insert into members
     values ('kingdora@gragon.com', '1234', '김개동', sysdate);

insert into members
     values ('hongkd@aaa.com', '1111', '홍길동', sysdate);
     
select*
from members;

select id, passwd from members where id='aaa';

