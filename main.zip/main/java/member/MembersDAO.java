package member;
import java.sql.*;
import javax.sql.*;
import javax.naming.*;

public class MembersDAO {
	
	private static MembersDAO instance = new MembersDAO();
	
	public static MembersDAO getInstance() {
			return instance;
	}
	
	private MembersDAO(){ }
	
	private Connection getConnection() {
		try {

			InitialContext ic = new InitialContext(); //JNDI 서버 객체 생성
			DataSource ds = (DataSource)ic.lookup("java:comp/env/jdbc/StudyJSP");
			Connection conn = ds.getConnection();
			return conn;
		}catch(Exception e) {
			System.out.println("데이터 베이스 연결에 문제가 생겼습니다.");
			return null;
		}
		
		
	}
	
	public void insertMember (MembersVO member) {
		Connection conn = null;
		PreparedStatement pstmt = null ;
		
		try {
			conn= getConnection();
			String sql = "insert into members values (?, ?, ?, sysdate)";
			pstmt = conn.prepareStatement(sql);//3.sql query를 실행하기 위한 객체 생성하기
			pstmt.setString(1, member.getId());
			pstmt.setString(2, member.getPasswd());
			pstmt.setString(3, member.getName());
			pstmt.executeUpdate();//4.sql query 실행
		}catch(Exception e) {
			e.printStackTrace();
			System.out.println("members 테이블에 새로운 레코드 추가에 실패했습니다");
		}finally {
			if(pstmt != null) try {pstmt.close();}catch (SQLException se) {}
			if(conn != null) try {conn.close();}catch (SQLException se) {}
			
		}
	}
	public int userCheck(String id, String passwd) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int result = -1;
		
		try {
			conn = getConnection();
			
			String sql = "select id, passwd from members where id=?";
			pstmt = conn.prepareStatement(sql);//3.sql query를 실행하기 위한 객체 생성하기	
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();//4.sql query 실행
			System.out.println("id : " + id);
			if(rs.next()) {
				String rpasswd = rs.getString("passwd");
				if(passwd.equals(rpasswd)) {
					result = 1;//인증성공
				} else {
					result = 0;//패스워드 틀림
				}
			} else {
				result = -1;//아이디 없음
			}
			System.out.println("result2 : " + result);
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			//5.자원 해제 
			if(rs != null) try {rs.close();} catch(SQLException se) {}
			if(pstmt != null) try  {pstmt.close();}catch(SQLException se) {}
			if(conn != null) try {conn.close();} catch(SQLException se) {}
		}
		return result;
	}
}
