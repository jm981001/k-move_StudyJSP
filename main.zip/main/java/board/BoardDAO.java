package board;
import java.sql.*;
import javax.sql.*;
import javax.naming.*;

import java.util.ArrayList;
import java.util.List;

public class BoardDAO {
	
	private static BoardDAO instance = new BoardDAO();
	
	public static BoardDAO getInstance() {
			return instance;
	}
	
	private BoardDAO(){ }
	
	private Connection getConnection() {
		try {

			InitialContext ic = new InitialContext(); //JNDI 서버 객체 생성
			DataSource ds = (DataSource)ic.lookup("java:comp/env/jdbc/StudyJSP");
			Connection conn = ds.getConnection();
			return conn;
		}catch(Exception e) {
			System.out.println("데이터 베이스 연결에 문제가 생겼습니다.");
			return null;
		}
		
		
	}
	
	public void insertBoard (BoardVO article) {
		Connection conn = null;
		PreparedStatement pstmt = null ;
		
		try {
			conn= getConnection();
			
			String sql = "insert into board (num, writer, email, subject, passwd, reg_date, content)";
			sql += "values (board_seq.nextval, ?, ?, ?, ?, sysdate, ?)";
			pstmt = conn.prepareStatement(sql);//3.sql query를 실행하기 위한 객체 생성하기
			pstmt.setString(1, article.getWriter());
			pstmt.setString(2, article.getEmail());
			pstmt.setString(3, article.getSubject());
			pstmt.setString(4, article.getPasswd());
			pstmt.setString(5, article.getContent());
			
			pstmt.executeUpdate();//4.sql query 실행
			
		}catch(Exception e) {
			e.printStackTrace();
			System.out.println("members 테이블에 새로운 레코드 추가에 실패했습니다");
		}finally {
			if(pstmt != null) try {pstmt.close();}catch (SQLException se) {}
			if(conn != null) try {conn.close();}catch (SQLException se) {}
			
		}
	}
	public List<BoardVO> getArticles(int start, int end) {
		Connection conn = null;
		PreparedStatement pstmt = null;//query실행
		ResultSet rs = null;
		List<BoardVO> articleList = null;
		
		try {
			conn = getConnection();

			// select b .*
			// from(select rownum as rnum, a.*
			//	 from(select * from board order by num desc) a)b
			// where b.rnum >= 1 and b.rnum <=10;
			String sql = " select b .* ";
			sql += " from( select rownum as rnum, a.* ";
			sql += " from( select * from board order by num desc ) a)b ";
			sql += " where b.rnum >= ? and b.rnum <=? ";
			pstmt = conn.prepareStatement(sql);//3.sql query를 실행하기 위한 객체 생성하기	
			pstmt.setInt(1, start);
			pstmt.setInt(2, end);
			rs = pstmt.executeQuery();//4.sql query 실행
					
			if(rs.next()) {
				articleList = new ArrayList<BoardVO>();
				do {
					BoardVO article = new BoardVO();
					article.setNum(rs.getInt("num"));
					article.setWriter(rs.getString("writer"));
					article.setEmail(rs.getString("email"));
					article.setSubject(rs.getString("subject"));
					article.setPasswd(rs.getString("passwd"));
					article.setReg_date(rs.getTimestamp("reg_date"));
					article.setReadcount(rs.getInt("readcount"));
					article.setContent(rs.getString("content"));
					
					articleList.add(article);
				}while(rs.next());
			}	
					
		} catch(Exception e) {
			e.printStackTrace();		
			System.out.println("board 테이블에 새로운 레코드 추가를 실패했습니다");		
		} finally {
			//5.자원 해제 
			if(rs != null) try {rs.close();} catch(SQLException se) {}
			if(pstmt != null) try  {pstmt.close();}catch(SQLException se) {}
			if(conn != null) try {conn.close();} catch(SQLException se) {}
		}
		return articleList;
	}	
	
	
	
	public int getArticleCount() {
		Connection conn = null;
		PreparedStatement pstmt = null ;
		ResultSet rs = null;
		int result = 0;
		
		try {
			conn = getConnection();
			
			String sql = "select count(*) from board";
			pstmt = conn.prepareStatement(sql);
			rs=pstmt.executeQuery();
			
			if(rs.next()) {
				result = rs.getInt(1);
			}
		}catch(Exception e) {
			e.printStackTrace();
			System.out.println("board 테이블의 자료 수 검색을 실패했습니다");
		}finally {
			if(rs != null) try {rs.close();} catch (SQLException se) {}
			if(pstmt != null) try {pstmt.close();} catch (SQLException se) {}
			if(conn != null) try {conn.close();} catch (SQLException se) {}
			
		}
		
		return result;
	}
				
					
	public BoardVO getArticle(int num) {
		Connection conn = null;
		PreparedStatement pstmt = null;//query실행
		ResultSet rs = null;
		BoardVO article = null;
		
		try {
			conn = getConnection();//클릭하는순간 조회수 증가
			
			String sql = "update board set readcount=readcount+1 where num=?";
			pstmt = conn.prepareStatement(sql);//3.sql query를 실행하기 위한 객체 생성하기	
			pstmt.setInt(1, num);
			pstmt.executeUpdate();//4.sql query 실행
					
			
			sql = "select * from board where num=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, num);
			rs=pstmt.executeQuery();//4.sql query 실행
			
			
			if(rs.next()) {
				article = new BoardVO();
				article.setNum(rs.getInt("num"));
				article.setWriter(rs.getString("writer"));
				article.setEmail(rs.getString("email"));
				article.setSubject(rs.getString("subject"));
				article.setPasswd(rs.getString("passwd"));
				article.setReg_date(rs.getTimestamp("reg_date"));
				article.setReadcount(rs.getInt("readcount"));
				article.setContent(rs.getString("content"));
					
			}	
					
		} catch(Exception e) {
			e.printStackTrace();		
			System.out.println("board 테이블에 상세보기의 레코드 검색을 실패했습니다");		
		} finally {
			//5.자원 해제 
			if(rs != null) try {rs.close();} catch(SQLException se) {}
			if(pstmt != null) try  {pstmt.close();}catch(SQLException se) {}
			if(conn != null) try {conn.close();} catch(SQLException se) {}
		}
		return article;
	}
	
	public BoardVO getArticleUpdate(int num) {
		Connection conn = null;
		PreparedStatement pstmt = null;//query실행
		ResultSet rs = null;
		BoardVO article = null;
		
		try {
			conn = getConnection();//클릭하는순간 조회수 증가
			String sql = "select * from board where num=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, num);
			rs=pstmt.executeQuery();//4.sql query 실행
			
			
			if(rs.next()) {
				article = new BoardVO();
				article.setNum(rs.getInt("num"));
				article.setWriter(rs.getString("writer"));
				article.setEmail(rs.getString("email"));
				article.setSubject(rs.getString("subject"));
				article.setPasswd(rs.getString("passwd"));
				article.setReg_date(rs.getTimestamp("reg_date"));
				article.setReadcount(rs.getInt("readcount"));
				article.setContent(rs.getString("content"));
					
			}	
					
		} catch(Exception e) {
			e.printStackTrace();		
			System.out.println("board 테이블에 상세보기의 레코드 검색을 실패했습니다");		
		} finally {
			//5.자원 해제 
			if(rs != null) try {rs.close();} catch(SQLException se) {}
			if(pstmt != null) try  {pstmt.close();}catch(SQLException se) {}
			if(conn != null) try {conn.close();} catch(SQLException se) {}
		}
		return article;
	}	
	
	public int updateBoard (BoardVO article) {
		Connection conn = null;
		PreparedStatement pstmt = null ;
		ResultSet rs = null;
		String rpasswd = "";
		int result=0;
		
		try {
			conn= getConnection();
			
			String sql = "select passwd from board where num = ?";
			pstmt = conn.prepareStatement(sql);//3.sql query를 실행하기 위한 객체 생성하기
			pstmt.setInt(1, article.getNum());
			rs = pstmt.executeQuery();//4.sql query 실행
			
			if(rs.next()) {
				rpasswd = rs.getString("passwd");
				
				if(rpasswd.equals(article.getPasswd())){
					sql = "update board set writer=?, email=?, subject=?, content=? where num=?";
					pstmt = conn.prepareStatement(sql);
					pstmt.setString(1, article.getWriter());
					pstmt.setString(2, article.getEmail());
					pstmt.setString(3, article.getSubject());
					pstmt.setString(4, article.getContent());
					pstmt.setInt(5, article.getNum());
					pstmt.executeUpdate();//4.sql query 실행
					result = 1;
				}else {
					result = 0;
				}
			}
			
			
		}catch(Exception e) {
			e.printStackTrace();
			System.out.println("board 테이블의 글 수정을 실패했습니다");
		}finally {
			if(rs != null) try {rs.close();}catch (SQLException se) {}
			if(pstmt != null) try {pstmt.close();}catch (SQLException se) {}
			if(conn != null) try {conn.close();}catch (SQLException se) {}
			
		}
		return result;
	}	
	
	
	
	 public int deleteBoard (int num, String passwd) {
	        Connection conn = null;
	        PreparedStatement pstmt = null ; //query 실행
	        ResultSet rs = null;
	        String rpasswd="";
	        int result=0;
	        
	        try {
	           conn= getConnection();
	           
	           String sql = "select passwd from board where num = ?";
	           pstmt = conn.prepareStatement(sql);
	           pstmt.setInt(1, num);
	           rs = pstmt.executeQuery();
	           
	           if(rs.next()) {
	              rpasswd = rs.getString("passwd");
	              if(rpasswd.equals(passwd)) {
	                 sql = "delete from board where num=?";
	                 pstmt = conn.prepareStatement(sql); //3. sql query
	                 pstmt.setInt(1, num);
	                 
	                 pstmt.executeUpdate(); 
	                 result = 1;
	              } else {
	                 result = 0;
	              }
	           }
	        }catch(Exception e) {
	           e.printStackTrace();
	           System.out.println("board 테이블의 글 삭제를 실패했습니다.");
	        
	        }finally {
	           if(rs != null) try {rs.close();} catch(SQLException se) {}
	           if(pstmt != null) try {pstmt.close();}catch (SQLException se) {}
	           if(conn != null) try {conn.close();}catch (SQLException se) {}
	        }
	        
	        return result;
	     }
}